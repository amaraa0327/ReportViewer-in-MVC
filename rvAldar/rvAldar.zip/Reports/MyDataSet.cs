﻿namespace rvAldar.Reports {
    
    
    public partial class MyDataSet {
    }
}
